# Quick go-through script

Approximate length: 6-8 minutes.

## Slide 1 — GraphRAG vs LightRAG

Hi everyone. This is a quick preview of my sharing on GraphRAG and LightRAG.

I am not trying to find one universal winner. The main question is: both tools use graphs, but where do they place the work, and which tasks fit each design better?

I use the same CORDIS dataset for both systems, then compare their graph artifacts and answer behavior.

## Slide 2 — Quick GraphRAG recap

Because the previous GraphRAG sharing was more than a year ago, I will start with a short recap.

GraphRAG extracts entities and relationships from documents. It builds a semantic graph, detects communities, and creates community reports before query time.

Its local, global, and DRIFT searches use different parts of these artifacts. The key point is that GraphRAG does a lot of preparation during indexing.

## Slide 3 — LightRAG principle

LightRAG also builds a graph, so it is not simply vector RAG.

It stores chunks, entities, relationships, and vectors. At query time, it retrieves low-level signals, such as entities and relations, and high-level signals, such as themes and concepts.

The important difference is that it does not create GraphRAG-style community reports. It builds the context more directly around each query.

## Slide 4 — The real difference

This is the main idea of the sharing.

GraphRAG spends more of its intelligence budget at indexing time. It creates richer graph artifacts and precomputed summaries.

LightRAG puts more weight on retrieval and context assembly at query time. This can make iteration lighter, but it gives us a different set of artifacts.

So the trade-off is not graph versus no graph. It is mainly where the work happens.

## Slide 5 — Why CORDIS

I chose a connected group of CORDIS projects and companies.

The project objectives give us useful natural-language content. Stable project and company IDs give us exact ground truth. Repeated companies also create a connected network, so we can test graph traversal.

CORDIS is only the evaluation substrate. It is not the main topic of the sharing.

## Slide 6 — Experimental setup

Both systems receive the same 41 enriched project documents and the same evaluation questions.

I keep the model and embedding setup aligned where the frameworks allow it. However, equal parameter values do not always mean equal behavior, because the frameworks process and retrieve information differently.

The indexes and benchmark runs are now complete.

## Slide 7 — Explicit facts

First, both systems recover the closed participation facts very well.

They cover all selected projects and companies, and they recover the participation and shared-project edges in scope.

This tells us that basic fact recovery is not the main difference. We need harder tasks to see how their behavior changes.

## Slide 8 — Different graph artifacts and demo

Before looking at answer quality, the graph artifacts are already different.

GraphRAG produces more entities and relationships, plus 206 community reports. LightRAG produces a smaller graph and has no native community-report layer.

The dual-graph visualizer lets us inspect both sides. I can search for a company, project, or topic, then compare density, labels, neighborhoods, and source information. The LightRAG clusters in this demo are visual clusters, not the same thing as GraphRAG community reports.

## Slide 9 — Scenario-level benchmark

This slide summarizes all ten task types.

For direct factual lookup and one-hop relations, the two systems are close.

GraphRAG is stronger on valid multi-hop paths, false-premise rejection, and both project-level and portfolio-level synthesis.

LightRAG performs better on pairwise comparison. It is also attractive for similar-project discovery, easier-to-read file references, and a lower total query-time budget in this run.

Two details are important. The discovery result is mixed, not a universal win. Also, lower total query time in this run does not mean LightRAG is always faster in every mode.

## Slide 10 — Practical decision guide

My current conclusion is to route by task type.

I would prefer GraphRAG when path correctness, false-premise protection, or broad structured synthesis matters.

I would prefer LightRAG for lighter exploration, pairwise comparison, easy-to-inspect references, or when the total query-time budget matters.

That is the story I plan to share: these tools are not simple replacements for each other. Their different architectures create different strengths.

For the full sharing, I will spend more time on the principles, show the visualizer, and explain how the evaluation was built.
