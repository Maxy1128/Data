# GraphRAG vs LightRAG sharing

This package contains the presentation and a self-contained interactive graph visualizer.

## Files

- `GraphRAG_vs_LightRAG_sharing.pptx` — editable PowerPoint deck.
- `WALKTHROUGH_SCRIPT.md` — short English script for a quick internal review.
- `docs/index.html` — self-contained dual-graph visualizer used by the presentation.

The visualizer contains its graph data, CSS, and JavaScript inside one HTML file. It does not require external JSON/CSV files or a CDN.

## Open locally

Download or clone the whole repository. Keep the PPTX and the `docs` folder in their current relative locations.

Open `GraphRAG_vs_LightRAG_sharing.pptx`, then click **dual-graph visualizer**. The packaged deck links to `docs/index.html`.

If PowerPoint shows a security warning for the hyperlink, allow the link only if you trust this repository. You can also open `docs/index.html` directly in a modern browser.

## Publish with GitHub Pages

1. Create a GitHub repository and upload everything in this folder.
2. Open the repository's **Settings → Pages**.
3. Under **Build and deployment**, choose **Deploy from a branch**.
4. Select the main branch and the `/docs` folder, then save.
5. GitHub will publish the demo at a URL similar to:

   `https://YOUR-USERNAME.github.io/YOUR-REPOSITORY/`

For the most portable PPTX, replace the relative hyperlink on **dual-graph visualizer** with that full GitHub Pages URL after it is available. This allows people who receive only the PPTX to open the demo.

Do not use the GitHub `raw` file URL as the presentation link. Use the GitHub Pages URL so the browser runs the HTML normally.

## Demo flow

1. Search for `ATOS SPAIN SA`, `RESISTO`, or `BLOCKCHAIN`.
2. Compare graph density and labels between the two panels.
3. Toggle node labels, edge labels, type filters, and degree filters.
4. Use the community selectors. GraphRAG communities may have real reports; LightRAG clusters are visual groupings only.
5. Click nodes and compare descriptions and source references.

The visualizer compares graph artifacts. It is not, by itself, an answer-quality benchmark.
